package BSWeb.repo;

import BSWeb.models.Achievements;
import org.springframework.data.repository.CrudRepository;

public interface AchievementsRepository extends CrudRepository<Achievements, Long> {

}

package BSWeb.repo;

import BSWeb.models.SECAchieve;
import org.springframework.data.repository.CrudRepository;

public interface SECAchieveRepository extends CrudRepository<SECAchieve, Long> {

}

